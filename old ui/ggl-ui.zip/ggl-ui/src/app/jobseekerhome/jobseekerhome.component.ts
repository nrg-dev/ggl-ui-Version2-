import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobseekerhome',
  templateUrl: './jobseekerhome.component.html',
  styleUrls: ['./jobseekerhome.component.css']
})
export class JobseekerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
