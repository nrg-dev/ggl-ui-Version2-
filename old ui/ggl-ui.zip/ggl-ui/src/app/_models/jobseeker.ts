﻿import { Common } from "./common";

export class Job extends Common{
	 name:string;
	// industry:string;

}
