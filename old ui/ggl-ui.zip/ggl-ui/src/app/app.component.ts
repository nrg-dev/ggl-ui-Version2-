import { Component } from '@angular/core';
import '../assets/app.css';

@Component({

    moduleId: module.id.toString(),
    selector: 'app',
    templateUrl: 'app.component.html'
})
//const express = require('express');

export class AppComponent {
  //http = require('http'),path = require('path'),compression = require('compression');

  title = 'app';
}
